import React, { Component } from "react";

// CUIDADO! SI O SI CLASS COMPONENT! SINO SE ROMPEN LOS TEST EN CASO CONTRARIO!
class Nav extends Component {

  render() {
    
  }
}

export default Nav;
