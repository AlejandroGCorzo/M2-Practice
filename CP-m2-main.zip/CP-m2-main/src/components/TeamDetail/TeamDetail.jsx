import React from "react";

// CUIDADO!. SI O SI FUNCTIONAL COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
// TAMBIEN VAS A TENER QUE USAR HOOKS!
const TeamDetail = (props) => {
  return <div></div>;
};
export default TeamDetail;
