import React from "react";

// CUIDADO! SI O SI FUNCTIONAL COMPONENT! SINO SE ROMPEN LOS TEST EN CASO CONTRARIO!

const DetailCard = (props) => {
  return <div></div>;
};

export default DetailCard;
