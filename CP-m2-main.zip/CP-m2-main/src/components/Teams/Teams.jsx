import React, { Component } from "react";


// CUIDADO! TENES QUE USAR CLASS COMPONENT! SINO SE ROMPEN LOS TEST EN CASO CONTRARIO!

// TAMBIEN VAS A TENER QUE USAR EL METODO CONNECT DE REDUX, JUNTO A MAP_STATE_TO_PROPS

// Y MAP_DISPATCH_TO_PROPS!

export class Teams extends Component {
  
  render() {
   
  }
}




