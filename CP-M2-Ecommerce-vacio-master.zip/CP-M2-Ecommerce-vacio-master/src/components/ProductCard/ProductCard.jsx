import React from 'react';


  // FIJENSE DE HACERLO SI O SI CON FUNCTIONAL COMPONENT! SI NO LOS TEST NO PASAN.


const ProductCard = ({name, image, id, stock, price}) => {
 
 
};

export default ProductCard;